# Обходы RAZVILKA: аудит и очередь завершения

Дата: 31.10.2026. Исходная точка — commit
bae510bfacd74072cf80cbda60dfb36332ed5ab7, поверх исправлений панели PR #21.
Этот документ относится к исходникам ветки work/bypass-cleanup-20261031.
Он не меняет номер выпуска и не подтверждает обновление установленного роутера.

## Основной результат

В проекте уже есть общий транзакционный исполнитель:
[Adapter, CanaryAdapter и RuntimeReconciler](../internal/dataplane/manager.go).
Основная проблема — незавершённые связи между его частями и неодинаковая
готовность механизмов. Импорт профиля, наличие бинарника, native validation,
изолированная проба, применённый маршрут и работа сервиса с LAN-клиента должны
оставаться разными состояниями.

Проверены регистрация исполнителей, импорт и установка компонентов, проверки
подключений, стратегия применения, здоровье, восстановление и отображение
результатов. Реальные роутеры и внешние учётные записи в этом проходе не менялись.
Ни новый механизм перехвата, ни дополнительная платформа не объявлены готовыми
по результату модульных тестов.

Сохраняется исходная задача продукта: пользователь выбирает сервисы, устройства
и допустимые способы один раз; система затем сама поддерживает эти подключения.
Исключения ресурсов и устройств сильнее включений. Несовпавший трафик сохраняет
обычную политику роутера, включая его собственный VPN. Пустой активный список
не даёт разрешения обрабатывать весь интернет.

## Реальное состояние механизмов

| Направление | Что подключено | Что ещё ограничивает готовность |
| --- | --- | --- |
| NFQWS2 | Собственные установка, managed source, native compatibility, выбор стратегии, ограниченные исполнения, health и восстановление hooks. | Production StrategyLab network executor не подключён. First-start TLS/TCP443 и managed LIST TCP/IPv4 — разные ограниченные пути, а не универсальный TCP/QUIC/voice исполнитель. Обновление уже управляемого пакета остаётся отдельной задачей. |
| VLESS через sing-box | Импорт, временная проверка точного узла, измерения, runtime-адаптер, применение и восстановление в поддержанном scope. | Временное ядро создаётся на каждую полную проверку. Domain-flow authority для общего адресного перехвата не реализована. Аппаратная приёмка всех режимов не завершена. |
| VLESS через Xray | Отдельный проверяющий исполнитель и runtime; строгие RAW/TCP TLS/REALITY и поддержанный XHTTP. | Поддержка конкретного transport зависит от профиля и native версии. Она не означает поддержку произвольной конфигурации Xray или всех LAN-сценариев. |
| Hysteria2, TUIC, Shadowsocks | Канонический импорт и общий проверяющий путь sing-box. | Проверка HTTPS через узел не подтверждает произвольное UDP-приложение. Для UDP-транспортов TCP-пинг неприменим. Другие протоколы не следуют автоматически из списка возможностей самого sing-box. |
| Обычный WireGuard | Профили своего сервера; stage, canary, apply, live health, rollback/reconcile. | Требуются совместимые kernel/tools и допустимый scope. Domain-only маршрут не разрешается по одному DNS-адресу. |
| WARP WireGuard | Регистрация/профиль, перебор endpoint-портов, handshake, проверка WARP и выбранного сервиса, транзакционный runtime. | Регистрация аккаунта не доказывает работу туннеля. Переиздание учётных данных и аппаратное восстановление требуют отдельной приёмки. |
| AmneziaWG | Parser/import и runtime с canary, apply, health, rollback. | Реальный backend — проверенный загруженный модуль ядра и соответствующий awg CLI. Userspace-исполнитель и автоматическая поставка модулей не реализованы. |
| USQUE / MASQUE | USQUE SOCKS + sing-box/gVisor TUN, выбор QUIC/HTTP2, owned probes, apply/health/reconcile/rollback и NDMC repair. | Два процесса — явная зависимость. QUIC до Cloudflare не подтверждает UDP forwarding или доступ LAN-клиента. Vendor init требует контроля при установке. |
| Telegram | Сервис, отдельный вариант с CIDR для VPN/прокси, диагностические HTTPS/MTProto soak-инструменты. | Отдельного Telegram tunnel/MTProxy/telemt runtime нет. HTTPS и ограниченный неаутентифицированный MTProto probe не доказывают чаты, медиа и звонки. |
| DNS для выбранного сервиса | Реальный Linux dns-scoped executor с listener, ограниченным DNAT и общей транзакцией. | DIRECT, один сервис/профиль/частный IPv4-клиент /32, точные домены, DNS клиента к LAN-адресу роутера:53. Не перехватывает клиентский DoH и не является глобальной заменой DNS. |
| Smart DNS / AdGuard DNS | Каталог и диагностика; производственный DoH-профиль может участвовать в разрешённом scoped DNS. | Smart DNS lab/experimental профили не получают live apply или autopilot после успешного probe. AdGuard DNS — resolver profile, а не управление AdGuard Home. |
| Mihomo | Строгий preview/export поддержанного узла. | Нет production installer, зарегистрированного runtime/checker, native validation, apply, health и recovery. |
| HevSocks5Tunnel | Генератор и opt-in constructor для контролируемого стенда. | Обычный startup его не включает. Нет production package/admission/аппаратной приёмки. |
| dns / relay в policy vocabulary | Зарезервированные имена. | Самостоятельных исполнителей с этими именами нет. AUTO, DIRECT, retain и block также не являются дополнительными ядрами обхода. |

Основные источники:
[регистрация runtime](../cmd/razvilka/main.go),
[контракт импорта](../internal/providerprofile/profile.go),
[Xray compiler](../internal/providerprofile/xray.go),
[проверяющий механизм](../internal/dataplane/nodecheck.go),
[WireGuard lifecycle](../internal/dataplane/warpwg.go),
[proxy lifecycle](../internal/dataplane/proxy.go),
[AWG runtime capabilities](../internal/awgprofile/runtime_capabilities.go),
[DNS scope](../internal/dataplane/scoped_dns_plan.go),
[DNS profile admission](../internal/dnscontrol/profile_identity.go),
[Mihomo/HEV API](../internal/app/extension_lab.go),
[HEV opt-in](../internal/dataplane/hev_sidecar.go).

### Почему нельзя просто убрать отказы domain scope

Общий IP CDN не идентифицирует отдельный сайт. Текущие IP-based VPN/proxy
исполнители получили бы и чужой трафик, если разрешить domain-only route без
доказательства принадлежности каждого потока выбранному сервису. Ограничение
DOMAIN_FLOW_AUTHORITY_REQUIRED в [планировщике](../internal/dataplane/plan.go)
и исполнителях сохраняется. Завершать нужно точный механизм маршрутизации,
согласованный с DNS и исключениями.

Аппаратная поддержка также не определяется одной успешной компиляцией.
Текущие managed LIST пути привязаны к проверенному профилю NC-1812;
MIPS/MIPSel и другие модели требуют собственных реализаций и приёмки.
См. [матрицу платформ](RUNTIME_SUPPORT_RU.md).

## Исправления этого прохода

### 1. Продолжение первого автоматического поиска

Устранено смешение продолжения конечного списка кандидатов с периодической
перепроверкой уже применённого маршрута. После успешно завершённой ограниченной
партии с монотонным продвижением сохранённого cursor следующий холодный раунд
назначается через существующий такт reconciler — 5 секунд.

Существующая операция feeds учитывает этот срок. Новый daemon, отдельная очередь
или обход admission не добавлены. CandidatesPerRound не увеличен; сохраняются
чередование сервисов, Stop, manual, Safe Mode, CAS и проверки разрешений.

Ограничение: timeout/ротация без успешно законченного продвижения, RetryAt,
исчерпанный/остановленный поиск, rate limit и восстановление уже применённого
маршрута сохраняют прежние правила. Фактический старт может задерживаться
другими операциями, checker и cleanup. Пять секунд — срок следующей попытки
координатора, не обещание подобрать узел за пять секунд.

В новых интеграционных тестах исходный worker оставлял около 120 секунд,
а feeds сохранял обычный следующий срок около 30 секунд. Это тест расписания,
не замер производительности роутера.

Код: [first usable](../internal/app/autonomy_first_usable.go),
[выбор раунда](../internal/app/autonomy_round_selection.go),
[reconciler](../internal/app/reconciler.go).
Регрессии: [autonomy_continuation_test.go](../internal/app/autonomy_continuation_test.go).

### 2. Параллельная пара измерений выхода

Прямая и проксированная пробы внешнего IP больше не ждут ответа друг друга.
Обе используют один заранее закреплённый адрес одного HTTPS-провайдера.
Следующий провайдер получает целую новую пару; половины от разных провайдеров
не смешиваются.

Отказ по scope отменяет соседний запрос и удаляет обе части результата.
До возврата и перехода к следующему провайдеру завершаются оба getter.
Общий бюджет, TLS, прямой отрицательный контроль, отбрасывание совпадающих IP
и ограничения числа временных ядер сохранены.

Подтверждена одновременность начала двух проб и сохранение отказов в локальных
TLS/SOCKS-фикстурах. Ускорение на конкретном роутере в процентах не измерялось.

Код: [node_egress.go](../internal/dataplane/node_egress.go).
Регрессии: [parallel](../internal/dataplane/node_egress_parallel_test.go),
[provider/TLS/SOCKS controls](../internal/dataplane/node_egress_test.go).

### 3. Полная длительность одной проверки и показ результата

Время checker теперь включает его начальную validation, сетевые пробы и
завершающую очистку. Успешный cleanup имеет отдельный stage с длительностью.
Повторное завершение измерения не продлевает срок годности доказательства.
Ожидание очереди до вызова checker по-прежнему является отдельным интервалом.

Панель показывает полученный статус проверки до завершения вспомогательных
запросов fallback и каталога. Проверки session/read epoch и single-flight
сохранены. Это прогрессивное отображение: полный цикл polling всё ещё может
ждать вспомогательные чтения.

Исправлена привязка измерений Xray: точный Xray result теперь отображается,
а более новый Xray check не оставляет старое sing-box timing. Поправлены
подписи назначения Xray, длительности и объёма «Все VLESS»; ложное обещание
завершения всей кнопки за 45 секунд убрано.

Код: [nodecheck.go](../internal/dataplane/nodecheck.go),
[node-browser.js](../cmd/razvilka/web/node-browser.js).
Регрессии: [timing](../internal/dataplane/nodecheck_timing_test.go),
[measurement UI](../scripts/test-node-measurements-ui.mjs),
[browser lifecycle](../scripts/test-node-browser-ui.mjs).

### 4. Жизненный цикл результатов StrategyLab

Выявлен ложный Healthy/Eligible: повторный импорт сохранял deterministic ID,
создавал новый incarnation и сбрасывал validation, но прежние сетевые PASS
оставались применимыми. Повторный Native PASS мог оживить старый quorum.
Та же проблема затрагивала выбор rollback alternative.

Каждая новая native validation получает отдельный случайный Generation ещё
до вызова validator. Сетевая проба связывается с incarnation кандидата и этой
generation, захваченными до её начала. Запоздалый результат не может получить
идентичность уже изменённого кандидата. Record проверяет обе привязки.

История остаётся в файле и в общих счётчиках. Текущие quorum, confidence,
coverage, Healthy/Eligible, последовательные отказы и выбор rollback alternative
учитывают только результаты для текущего incarnation и успешной native validation.
Старый unbound PASS не становится действительным после перезапуска, повторного
импорта или нового Native PASS, даже если timestamps совпали. Ручной выбор
сохраняется, но исторический результат не придаёт ему проверенный статус.

Общий unknown fence также отражается в Snapshot и панели: готовность и здоровье
не объявляются подтверждёнными до завершения проверки состояния процесса.
Исторический PASS без актуального измерения не отображается как TTFB 0 мс.
Сами наблюдения, счётчики и намерение пользователя при этом сохраняются.

**Совместимость состояния:** читаются прежние схемы 1/2/3 и новые 4/5.
Обычные новые записи используют 4, supervised-публикации — 5; старый бинарник,
поддерживающий только 1/2/3, откажется читать их. Это намеренная защита от
возврата к старому трактованию evidence, а не совместимый downgrade.
Чтение само не переписывает файл. Точный receipt/ACK уже существующего helper
схемы 3 сохраняет её формат ради полного совпадения CAS; новая validation
публикуется в 5. При успешном сохранении неизвестное состояние обычного
процесса фиксируется схемой 2. Если CAS из схемы 4 не удался, текущий Manager
удерживает unknown/write fence в памяти, не перезаписывая чужой файл.

Прежние наблюдения не удаляются и не получают новую привязку автоматически.
Для возврата проверенного статуса нужны актуальная native validation и новые
сетевые пробы; кандидату без incarnation также требуется повторный импорт.
Обновление и восстановление на реальном роутере должны учитывать изменение
формата. В этом проходе router state не мигрировался.

Ограничение отката существенное: старый startup завершает весь процесс при
неподдерживаемой схеме StrategyLab, поэтому панель тоже не откроется.
strategy-lab.json не входит ни в текущий encrypted private backup, ни в реестр
private images self-update. Откат бинарника вместе с таким backup не является
подтверждённым восстановлением. До выпуска нужен проверенный сценарий
обновления/отката, сохраняющий состояние и запреты; удалять файл для запуска
старого бинарника нельзя считать исправлением.
Источники: [startup](../cmd/razvilka/main.go),
[состав private backup](../internal/privatebackup/privatebackup.go),
[private images self-update](../internal/updatecheck/file_private_formats.go).

Код: [StrategyLab](../internal/strategylab/strategylab.go),
[evidence](../internal/strategylab/evidence.go),
[supervised publication](../internal/strategylab/compatible_supervised_publication.go),
[managed publication](../internal/strategylab/compatible_managed_publication.go).
Регрессии: [eligibility_validation_test.go](../internal/strategylab/eligibility_validation_test.go),
[evidence_binding_test.go](../internal/strategylab/evidence_binding_test.go).
Версии и правила записи: [state_schema.go](../internal/strategylab/state_schema.go).

### 5. Точная причина отказа WARP и реальные требования AWG

WARP больше не сообщает «handshake не подтверждён на всех портах», если
handshake уже был подтверждён, а отказала последующая provider trace.
Сохраняются ошибки всех ограниченных попыток, включая смешанный случай:
подтверждённый handshake на одном порту и transport failure на следующем.
Полноценный успех по другому порту и обязательная проверка сервиса сохранены.

Описание AmneziaWG теперь требует реально поддержанный kernel backend и
проверенный awg CLI. Обещание альтернативного userspace runtime убрано.

Код: [WARP canary](../internal/dataplane/wg_canary_checks.go),
[каталог компонентов](../internal/components/components.go).
Регрессии: [wg_canary_failure_test.go](../internal/dataplane/wg_canary_failure_test.go).

## Очередь завершения для Codex

Работать от текущей ветки с сохранением уже проверенных fixes. Не заменять
существующие Adapter/CanaryAdapter/RuntimeReconciler ещё одним параллельным
framework. Каждая задача должна завершаться работающим сценарием и проверкой
его отказов, а не добавлением ещё одной кнопки или интерфейса без исполнителя.

| Приоритет | Задача | Условие завершения |
| --- | --- | --- |
| P0 | Связать полный managed NFQWS2 StrategyLab workflow. | Кандидат проходит supervised compatibility, управляемую scoped network probe, получает актуальное связанное evidence, выбирается, применяется, наблюдается и откатывается. Production startup подключает настоящий scoped consumer. Legacy raw SystemProbeExecutor не включается снятием ограничения. |
| P0 | Завершить точную маршрутизацию выбранных сервисов и исключений. | Доменный выбранный сервис получает рабочий обход; другой домен на том же CDN IP, исключённое устройство и обычный VPN роутера сохраняют свои пути. DNS, классификация и runtime используют одно применённое поколение. |
| P0 | Разделить capabilities и состояние в общей модели. | UI и AUTO получают из одного фактического runtime-контракта наличие installer, native validator, isolated probe, apply, health и recovery; export/lab не выглядит доступным production обходом. |
| P1 | Сделать быстрый protocol/URL check и измерить весь цикл. | Раздельные queue/admission/start/DNS/TCP/egress/service/cleanup/apply времена; один воспроизводимый набор живых и мёртвых узлов; p50/p95, ошибки, RAM/CPU до и после. Быстрый HTTPS результат не заменяет service или LAN evidence. |
| P1 | Сократить повторную работу checker. | Устранены повторные DNS/TCP и дублирование первого service IP в пределах доказанной свежести. Повторное использование ограниченного числа изолированных ядер допустимо только после проверки смены поколения, отмены и cleanup. |
| P1 | Завершить восстановление и обновление компонентов. | NFQWS2 managed update, WG/WARP/AWG/USQUE recovery и зависимости переживают обрыв, reboot, WAN change, failed update и rollback с сохранением работающих чужих сервисов. |
| P1 | Закрыть прикладные критерии. | Отдельно подтверждены требуемые функции: HTTPS, видео, MTProto, голос/UDP. UI не поднимает уровень доказательства по одному успешному HTTP-ответу. |
| P1 | Подтвердить поддерживаемые платформы. | Для каждого заявленного устройства проверены kernel/tools, ownership, правила и полный runtime lifecycle. MIPS/MIPSel/OpenWrt не объявляются готовыми по факту сборки бинарника. |
| P2 | Довести опциональные Mihomo/HEV. | Installer, native validation, тот же lifecycle, ограниченный scope и аппаратная приёмка; выбранный backend не меняет критерии готовности сервиса. |

### Обязательные свойства дальнейшей реализации

- Один владелец применения сетевого поколения, явные claims на порты,
  интерфейсы, правила и процессы; завершённый cleanup до освобождения владельца.
- Ошибки отмены, смены сети, недоступности control endpoint, запрета сервиса,
  несовместимого runtime и неудачной очистки различаются. Timeout не объявляет
  публичный ключ безусловно нерабочим.
- Повторный импорт, смена runtime, validation, WAN или service criteria
  не обновляют старое доказательство. История и текущая применимость разделены.
- Плановое обслуживание не добавляет неограниченную задержку срочному
  восстановлению; ограниченные очереди сохраняют fairness и возможность Stop.
- Для каждого заявленного режима проверяются первый запуск, повторный Apply,
  отказ внешнего узла, отмена, cleanup failure, reboot/WAN change и rollback.
  Физический LAN-тест остаётся самостоятельным доказательством.

## Проверка изменений

Новые регрессии сначала воспроизводили прежние дефекты; затем выполнены
целевые обычные и race-проверки изменённых подсистем, UI-проверки и vet.
Полный неизменённый scripts/check.sh должен пройти для точного опубликованного
commit; ссылки на CI и точные результаты фиксируются в PR, чтобы не создавать
самоссылочную смену commit ради записи его же SHA в этом документе.

Часть локальных native-фикстур требует loopback, chown и безопасного временного
родителя. Песочница давала отказ socket/chown и timeout дочернего shell.
Адресные проверки повторялись в разрешённой среде, без пропуска assertions;
для Go native fixtures GOTMPDIR задавался в /tmp. Это условия тестовой среды,
а не основание ослаблять runtime-проверки в продукте.

Аппаратные показатели скорости, 24–72-часовой прогон, WAN/reboot/power-loss
и работоспособность приложений с реального LAN-клиента здесь не измерялись.
Стабильный выпуск, merge и установка на роутер этим документом не выполняются.

## Повторная сверка контрактов 31.10.2026

Сверено по исходникам `a36f534339f2a9ccf37956537a527ae77f7d0d59`.
Эта сверка подтверждает наличие связей в коде; новые native/LAN/аппаратные
испытания в её рамках не выполнялись. Исторические результаты CI выше относятся
к своим commit и не заменяют проверки интегрированного изменения.

| Механизм | Вход и validation / isolated probe | Apply, health, recovery | Update / rollback и следующий блокер |
| --- | --- | --- | --- |
| NFQWS2 | Managed bundle и supervised compatibility; StrategyLab startup оставляет `Executor = nil` | Зарегистрированный адаптер и ограниченные first-start / LIST пути; полного пути StrategyLab candidate → network evidence → Apply нет | Общий managed-update механизм существует, но owned package/init защищены `NFQWS_OWNED_PROFILE_PACKAGE_UNSUPPORTED`; нужен совместимый managed bundle update, включая recovery |
| sing-box VLESS, Hysteria2, TUIC, Shadowsocks | Канонический импорт, native checker и изолированный URL/egress путь | Общий proxy adapter, health/reconcile/rollback в разрешённом scope | Общий guarded package update с cache/journal; проверка живого маршрута и аппаратный сценарий обязательны отдельно |
| Xray VLESS | Compiler и отдельный checker для поддержанных transport | Startup связывает Xray adapter с private node store; TUN sidecar — sing-box | Общий guarded package update; успешная проверка узла не снимает domain-flow отказ |
| WG / WARP | Профиль; canary, handshake, service/trace проверки различаются | Зарегистрированные WG/WARP adapters с health/reconcile/rollback | Общий managed package update предусмотрен; cold handshake, WAN/reboot и восстановление проверяются на целевой системе |
| AWG | Импорт и runtime preflight требуют совместимого модуля и awg CLI | Зарегистрированный адаптер; разрешённый scope и native prerequisites обязательны | В общем списке managed-update компонентов AWG отсутствует; автоматической поставки kernel backend нет |
| USQUE/MASQUE | Профиль и owned probes; sing-box является runtime dependency | Зарегистрированный proxy adapter, SOCKS → sing-box/gVisor TUN, health/reconcile/rollback | Общий guarded package update; QUIC/HTTP2 до провайдера не доказывает LAN UDP/голос |
| Telegram | Каталожный сервис; HTTPS и ограниченные MTProto diagnostics | Использует разрешённый NFQ/proxy/VPN путь, отдельного MTProxy adapter нет | Обновляется выбранный runtime; сообщения, медиа и звонки требуют отдельных прикладных проб |
| Scoped DNS / AdGuard DNS | Production resolver profile; lab/experimental не проходит scoped admission | `dns-scoped` регистрируется только на Linux; один DIRECT service/profile/private IPv4 /32, DNS к LAN:53 | Общая транзакция и listener cleanup; это не установка AdGuard Home, не перехват DoH и не весь IPv6 |
| Smart DNS lab | Каталог и диагностика | Production Apply/AUTO не разрешаются успехом диагностики | Требуется отдельное решение production admission и аппаратная приёмка |
| Mihomo | Preview/export с digest review | `live_applied=false`; adapter/checker в startup отсутствуют | Нет production installer/lifecycle |
| HEV | Генератор; `native_validated=false` | Только opt-in constructor программного стенда, обычный startup использует sing-box | Нет доверенного package, admission UI и аппаратной приёмки |

Источники уточнения: [startup](../cmd/razvilka/main.go),
[общий managed update](../internal/components/managed_update.go),
[проверки обновления маршрута](../internal/app/component_managed_update.go),
[owned NFQ package guard](../internal/app/component_nfqws_package_guard.go),
[extension API](../internal/app/extension_lab.go),
[HEV constructor](../internal/dataplane/hev_sidecar.go).
`DOMAIN_FLOW_AUTHORITY_REQUIRED` остаётся действующим ограничением общего
IP-based domain-only маршрута; успешный probe его не отменяет.

### Границы проверки сайта

В отслеживаемых файлах этой ветки найдены встроенная панель
`cmd/razvilka/web`, README и документация. В `.github/workflows` находятся
`ci.yml` и `release.yml`; отдельный сайт, его deployment workflow или CNAME
не установлены. Это не доказывает отсутствие внешнего сайта. Для проверки и
исправления опубликованного сайта нужен его конкретный URL и источник.
Проверка внешней опубликованной версии и deploy здесь не выполнены.
