package app

import (
	"context"
	"errors"
	"net/http"
	"slices"
	"strings"
	"sync"
	"time"

	"github.com/ArtixSx/razvilka/internal/catalog"
	"github.com/ArtixSx/razvilka/internal/config"
	"github.com/ArtixSx/razvilka/internal/dataplane"
	"github.com/ArtixSx/razvilka/internal/nodestore"
	"github.com/ArtixSx/razvilka/internal/operationgate"
)

type nodeCatalogCheckSpec struct {
	Generation      uint64 `json:"generation"`
	Matched         int    `json:"matched"`
	SelectionDigest string `json:"selection_digest,omitempty"`
}

var errNodeCatalogChanged = errors.New("node catalogue changed before acceptance")

// Catalogue references are resolved exactly once at admission. Retries compare
// the original selector, not health updates or later additions to the catalogue.
func durableRequestFingerprint(r serviceControlJobRequest) string {
	if r.Kind == "node-check" && r.NodeCatalog != nil {
		r.NodeIDs = nil
		selector := &nodeCatalogCheckSpec{Generation: r.NodeCatalog.Generation, SelectionDigest: r.NodeCatalog.SelectionDigest}
		if selector.SelectionDigest != "" {
			selector.Generation = 0
		}
		r.NodeCatalog = selector
	}
	return applyReviewHash(r)
}

func durableJobTotal(r serviceControlJobRequest) int {
	if r.Kind == "node-check" {
		return len(r.NodeIDs)
	}
	return len(r.ServiceIDs)
}

// Only frozen references enter the existing reconciler. Source URLs, node
// credentials and previously successful results are never replayable jobs.
func validDurableNodeCheck(r serviceControlJobRequest) bool {
	limit := maxNodeCheckBatch
	if r.NodeCatalog != nil {
		limit = nodestore.MaxNodes
		if r.NodeCheckMode != "service" || r.NodeCatalog.Generation == 0 || r.NodeCatalog.SelectionDigest != "" && !validJobHash(r.NodeCatalog.SelectionDigest) {
			return false
		}
		if r.resolveNodeCatalog {
			if len(r.NodeIDs) != 0 || r.NodeCatalog.Matched != 0 {
				return false
			}
		} else if r.NodeCatalog.Matched < len(r.NodeIDs) || r.NodeCatalog.Matched > limit {
			return false
		}
	} else if r.resolveNodeCatalog {
		return false
	}
	if r.ExpectedRevision == nil || r.NodeApply != nil || r.DNS != nil || (len(r.NodeIDs) == 0 && !r.resolveNodeCatalog) || len(r.NodeIDs) > limit {
		return false
	}
	if r.NodeCheckMode == "service" {
		if len(r.ServiceIDs) != 1 || len(r.ServiceIDs[0]) == 0 || len(r.ServiceIDs[0]) > 128 || strings.Trim(r.ServiceIDs[0], "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_.") != "" {
			return false
		}
	} else if r.NodeCheckMode != "tcp" && r.NodeCheckMode != "connectivity" || len(r.ServiceIDs) != 0 {
		return false
	}
	seen := map[string]bool{}
	for _, id := range r.NodeIDs {
		if !strings.HasPrefix(id, "node-") || !validJobHash(strings.TrimPrefix(id, "node-")) || seen[id] {
			return false
		}
		seen[id] = true
	}
	return true
}

func (a *App) validateDurableNodeCheckSelection(ctx context.Context, r *serviceControlJobRequest, services []catalog.Service) error {
	if a.Nodes == nil || r.NodeCheckMode == "service" && (a.NodeChecker == nil || len(services) != 1 || !serviceHasNodeProbe(services[0])) {
		return errServiceControlRequest
	}
	if r.NodeCheckMode == "connectivity" && a.NodeChecker == nil {
		return errServiceControlRequest
	}
	// Stopping live routes must not prevent checking a replacement. These
	// temporary probes never resume routing. A new Stop/revision still revokes
	// an in-flight batch through the immutable intent checked by the worker.
	snapshot, err := a.Nodes.Snapshot(ctx, time.Now())
	if err != nil {
		return err
	}
	if r.resolveNodeCatalog {
		if !matchesNodeCheckCatalog(snapshot, r.NodeCatalog.Generation, r.NodeCatalog.SelectionDigest) {
			return errNodeCatalogChanged
		}
		r.NodeIDs, r.NodeCatalog.Matched = allVLESSNodes(snapshot)
		r.resolveNodeCatalog = false
		if !validDurableNodeCheck(*r) {
			return errServiceControlRequest
		}
	}
	eligible := map[string]bool{}
	for _, node := range snapshot.Nodes {
		eligible[node.ID] = !node.Disabled && node.State != "expired"
	}
	for _, id := range r.NodeIDs {
		if !eligible[id] {
			return errServiceControlRequest
		}
	}
	return nil
}

// Enqueue only freezes read-only intent. It must not compete with a running
// service probe for network admission. The existing worker acquires the lease
// and revalidates all references/revision/definitions before its first IO.
func (a *App) prepareDurableNodeCheck(ctx context.Context, request *serviceControlJobRequest) (string, error) {
	if a.Store == nil {
		return "", errServiceControlRequest
	}
	if a.Operations.Snapshot().Fenced {
		return "", operationgate.ErrRecovery
	}
	if a.SelfUpdate != nil && a.SelfUpdate.InstallationLocked() {
		return "", operationgate.ErrBusy
	}
	cfg := a.Store.Get()
	if cfg.Revision != *request.ExpectedRevision {
		return "", config.ErrRevisionChanged
	}
	services := []catalog.Service{}
	for _, service := range a.catalogSnapshot().Services {
		if len(request.ServiceIDs) == 1 && service.ID == request.ServiceIDs[0] {
			services = append(services, service)
			break
		}
	}
	if len(services) != len(request.ServiceIDs) {
		return "", errServiceControlRequest
	}
	if err := a.validateDurableNodeCheckSelection(ctx, request, services); err != nil {
		return "", err
	}
	intent := durableServiceIntentHash(cfg, services)
	if current := a.Store.Get(); current.Revision != cfg.Revision || durableServiceIntentHash(current, services) != intent || len(services) == 1 && !a.nodeCheckDefinitionCurrent(services[0].ID, applyReviewHash(services[0])) {
		return "", config.ErrRevisionChanged
	}
	if a.Operations.Snapshot().Fenced {
		return "", operationgate.ErrRecovery
	}
	if err := ctx.Err(); err != nil {
		return "", err
	}
	return intent, nil
}

func (a *App) acceptDurableNodeChecks(w http.ResponseWriter, r *http.Request, q nodeCheckJobRequest) {
	request := serviceControlJobRequest{Kind: "node-check", NodeCheckMode: q.Mode, NodeIDs: q.NodeIDs, ExpectedRevision: q.ExpectedRevision, IdempotencyKey: q.IdempotencyKey}
	if q.Scope == allVLESSScope {
		request.NodeCatalog = &nodeCatalogCheckSpec{Generation: q.Generation, SelectionDigest: q.CatalogDigest}
		request.resolveNodeCatalog = true
	}
	if q.Mode == "service" {
		request.ServiceIDs = []string{q.ServiceID}
	}
	job, err := a.enqueueDurableServiceJob(r.Context(), request)
	if err != nil {
		a.writeDurableJobFailure(w, err)
		return
	}
	view := a.nodeCheckCurrentView()
	view["job"] = job.presentation()
	writeJSON(w, http.StatusAccepted, view)
}

func (a *App) nodeCheckCurrentView() map[string]any {
	view := a.nodeCheckSnapshot()
	if job, _ := view["job"].(*nodeCheckJob); job != nil && job.Timing != nil {
		job.Timing = nodeJobTimingView(job.Timing.EnqueuedAt, job.Timing, job.FinishedAt, time.Now().UTC())
	}
	a.addDurableServiceJobsView(view, true)
	view["durable_selected_checks"] = true
	view["durable_all_vless"] = true
	return view
}

type durableNodeCheckResult struct {
	network  string
	advanced int // nodes of the selection this step completed
}

func durableNodeCheckFailure(err error) string {
	switch {
	case errors.Is(err, context.DeadlineExceeded):
		return "check-timeout"
	case errors.Is(err, dataplane.ErrExactNodeNetworkChanged):
		return "network-unconfirmed"
	case errors.Is(err, config.ErrRevisionChanged), errors.Is(err, dataplane.ErrReviewChanged):
		return "settings-changed"
	case errors.Is(err, nodestore.ErrStore), errors.Is(err, nodestore.ErrRecovery):
		return "node-store-unavailable"
	case errors.Is(err, context.Canceled):
		return "interrupted"
	default:
		return "check-failed"
	}
}

func durableNodeCheckFailureMessage(reason string) string {
	switch reason {
	case "network-unconfirmed":
		return "Проверка остановлена: прежнее состояние сети больше не подтверждено. Результаты относятся к прежней сети; запустите новую проверку."
	case "check-timeout":
		return "Проверка остановлена по таймауту. Временные ресурсы освобождены; оставшиеся подключения не проверены."
	case "node-store-unavailable":
		return "Проверка остановлена: не удалось прочитать хранилище подключений. Откройте журнал и проверьте накопитель."
	case "settings-changed":
		return "Проверка остановлена: изменились настройки или определение сервиса. Запустите новую проверку."
	case "cleanup-unverified":
		return "Очистка временного подключения не подтверждена. Новые сетевые действия заблокированы; откройте журнал."
	}
	return "Проверка не завершена. Оставшиеся подключения не проверены; рабочие маршруты не изменены."
}

// One node per reconciler turn: route recovery and Stop get the next turn.
// The lease stays owned until the checker has joined all temporary cleanup.
func (a *App) runDurableNodeCheck(ctx context.Context, r serviceControlJobRequest, network string) (out durableNodeCheckResult, err error) {
	if !validDurableNodeCheck(r) || r.durableCursor < 0 || r.durableCursor >= len(r.NodeIDs) || a.Store == nil || a.Nodes == nil {
		return out, errServiceControlRequest
	}
	ctx, release, err := a.Operations.ExclusiveContext(ctx)
	if err != nil {
		return out, err
	}
	admittedAt := time.Now().UTC()
	enqueuedAt := a.durableNodeEnqueuedAt(r.durableID)
	var done chan struct{}
	defer func() {
		release()
		if done != nil {
			close(done)
		}
	}()
	services := []catalog.Service{}
	for _, service := range a.catalogSnapshot().Services {
		if len(r.ServiceIDs) == 1 && service.ID == r.ServiceIDs[0] {
			services = append(services, service)
			break
		}
	}
	cfg := a.Store.Get()
	if cfg.Revision != *r.ExpectedRevision || r.intentHash != durableServiceIntentHash(cfg, services) {
		return out, config.ErrRevisionChanged
	}
	if r.NodeCheckMode == "service" && (a.NodeChecker == nil || len(services) != 1 || !serviceHasNodeProbe(services[0])) {
		return out, errServiceControlRequest
	}
	if r.NodeCheckMode == "connectivity" && a.NodeChecker == nil {
		return out, errServiceControlRequest
	}
	profile, err := a.freshNetworkProfile(ctx)
	if err != nil || profile == "" {
		return out, dataplane.ErrExactNodeNetworkChanged
	}
	out.network = applyReviewHash(profile)
	if network != "" && network != out.network {
		return out, dataplane.ErrExactNodeNetworkChanged
	}
	checkCtx, cancel := context.WithCancel(ctx)
	if r.NodeCheckMode == "service" {
		var retire func()
		checkCtx, retire, err = a.manualNodeCandidateContext(checkCtx, r, cfg, services[0])
		if err != nil {
			cancel()
			return out, err
		}
		defer retire()
	}
	done = make(chan struct{})
	a.nodeChecks.mu.Lock()
	if a.nodeChecks.closed || a.nodeChecks.root == nil || a.nodeChecks.root.Err() != nil || ctx.Err() != nil {
		a.nodeChecks.mu.Unlock()
		cancel()
		return out, context.Canceled
	}
	if a.nodeChecks.cancel != nil {
		a.nodeChecks.mu.Unlock()
		cancel()
		return out, operationgate.ErrBusy
	}
	job := a.nodeChecks.job
	if job == nil || job.ID != r.durableID {
		job = a.nodeChecks.batchResults[r.durableID]
	}
	if job == nil {
		job = &nodeCheckJob{ID: r.durableID, Mode: r.NodeCheckMode, Total: len(r.NodeIDs), StartedAt: time.Now().UTC(), Results: []nodeCheckItem{}}
		if len(r.ServiceIDs) == 1 {
			job.ServiceID = r.ServiceIDs[0]
		}
		if r.NodeCatalog != nil {
			job.Scope, job.Matched, job.Skipped = allVLESSScope, r.NodeCatalog.Matched, r.NodeCatalog.Matched-len(r.NodeIDs)
		}
	}
	if job.Timing == nil && !enqueuedAt.IsZero() {
		job.Timing = nodeJobTimingView(enqueuedAt, &nodeJobTiming{FirstAdmittedAt: &admittedAt}, nil, admittedAt)
	}
	a.nodeChecks.job = job
	job.Completed, job.State, job.Phase, job.FinishedAt = r.durableCursor, "running", "checking", nil
	job.network = out.network
	job.EarlierNetworkCompleted = r.durableEpochStart
	job.Message = "Проверяем подключение. Между узлами очередь уступает восстановлению маршрутов."
	a.nodeChecks.cancel, a.nodeChecks.done = cancel, done
	a.nodeChecks.mu.Unlock()
	defer func() {
		cancel()
		a.nodeChecks.mu.Lock()
		if job := a.nodeChecks.job; job != nil && job.ID == r.durableID {
			job.State, job.Phase = "queued", "waiting"
			if err != nil {
				job.State, job.Message = "failed", nodeCheckFailureMessage(err)
			}
			a.nodeChecks.cancel = nil
		}
		a.nodeChecks.mu.Unlock()
	}()
	var service catalog.Service
	if len(services) == 1 {
		service = services[0]
	}
	snapshot, err := a.Nodes.Snapshot(checkCtx, time.Now())
	if err != nil {
		return out, err
	}
	available := map[string]bool{}
	for _, node := range snapshot.Nodes {
		if !node.Disabled && node.State != "expired" && (r.NodeCatalog == nil || strings.EqualFold(strings.TrimSpace(node.Protocol), "vless")) {
			available[node.ID] = true
		}
	}
	pinger := a.NodePinger
	if pinger == nil {
		pinger = dataplane.NewTCPNodePinger()
	}
	// A step covers a window of the frozen selection. Pings are only TCP
	// connects and run together. A service check first screens the window in
	// order and decides the nodes that fail DNS or transport (recorded as a
	// full check would record them), then checks up to the checker's capacity
	// of the others at once. With one slot and no screening, a step is one
	// node as before.
	capacity := a.nodeCheckCapacity()
	_, screens := a.NodeChecker.(dataplane.TransportScreener)
	limit := 1
	if r.NodeCheckMode == "tcp" || screens || capacity > 1 {
		limit = durableNodeWindow
	}
	ids := r.NodeIDs[r.durableCursor:min(r.durableCursor+limit, len(r.NodeIDs))]
	items := make([]nodeCheckItem, len(ids))
	eligible := make([]bool, len(ids))
	for i, id := range ids {
		eligible[i] = available[id]
		items[i] = nodeCheckItem{NodeID: id, CheckedAt: time.Now().UTC(), NetworkProfile: profile, ErrorCode: "bulk-node-skipped", Message: "Подключение удалено, отключено или истекло. Пропущено."}
	}
	pings := map[string]nodeCheckItem{}
	advanced := len(ids)
	if r.NodeCheckMode == "tcp" {
		eachNodeInParallel(len(ids), durableNodeWindow, func(i int) {
			if eligible[i] {
				items[i] = a.runNodeCheckItem(checkCtx, r.NodeCheckMode, ids[i], service, profile, pinger)
			}
		})
		for i := range ids {
			if eligible[i] {
				pings[ids[i]] = items[i]
			}
		}
	} else {
		decided := make([]bool, len(ids))
		screened := make([]nodeCheckItem, len(ids))
		if screens && r.NodeCheckMode == "service" {
			// Screens take the same non-blocking quota as checks, so at most
			// capacity run at once: a screen refused as busy would leave its
			// node undecided for nothing. Screening stops once it has found
			// the first undecided node beyond those this step checks in full,
			// because the step ends there. Its batch may have screened up to
			// capacity-1 later nodes; the next step screens them again.
			pending := []int{}
			for i := range ids {
				if eligible[i] {
					pending = append(pending, i)
				}
			}
			for undecided := 0; len(pending) > 0 && undecided <= capacity && checkCtx.Err() == nil; {
				batch := pending[:min(capacity, len(pending))]
				pending = pending[len(batch):]
				eachNodeInParallel(len(batch), capacity, func(k int) {
					i := batch[k]
					engine := a.checkOnlyNodeEngine(checkCtx, ids[i])
					result, final, err := a.screenAndRecordNodeForEngine(checkCtx, engine, ids[i], service, profile)
					if err != nil {
						return // A full check decides; it reports its own failure.
					}
					screened[i] = screenPing(ids[i], profile, result)
					if final {
						items[i], decided[i] = nodeCheckItemFromResult(ids[i], profile, result, nil, engine), true
					}
				})
				for _, i := range batch {
					if !decided[i] {
						undecided++
					}
				}
			}
		}
		full := []int{}
		advanced = 0
		for i := range ids {
			if eligible[i] && !decided[i] {
				if len(full) == capacity {
					break
				}
				full = append(full, i)
			}
			advanced++
		}
		eachNodeInParallel(len(full), capacity, func(k int) {
			i := full[k]
			items[i] = a.runNodeCheckItem(checkCtx, r.NodeCheckMode, ids[i], service, profile, pinger)
		})
		for i := range advanced {
			if items[i].ErrorCode == "node-cleanup-failed" {
				a.Operations.FenceJournal()
				return out, operationgate.ErrRecovery
			}
			if screened[i].NodeID != "" {
				pings[ids[i]] = screened[i]
			}
		}
		ids, items, eligible = ids[:advanced], items[:advanced], eligible[:advanced]
	}
	if checkCtx.Err() != nil {
		return out, checkCtx.Err()
	}
	if current, e := a.freshNetworkProfile(checkCtx); e != nil || current != profile {
		return out, dataplane.ErrExactNodeNetworkChanged
	}
	if r.intentHash != durableServiceIntentHash(a.Store.Get(), services) || len(services) == 1 && !a.nodeCheckDefinitionCurrent(services[0].ID, applyReviewHash(services[0])) {
		return out, config.ErrRevisionChanged
	}
	out.advanced = advanced
	a.nodeChecks.mu.Lock()
	defer a.nodeChecks.mu.Unlock()
	if job := a.nodeChecks.job; job != nil && job.ID == r.durableID {
		for i, item := range items {
			job.Results = append(slices.Clone(job.Results), item)
			if len(job.Results) > maxNodeCheckBatch {
				job.Results = slices.Clone(job.Results[len(job.Results)-maxNodeCheckBatch:])
			}
			job.Completed++
			switch {
			case !eligible[i]:
				job.Skipped++
			case item.Available && item.Verdict == "PASS" && item.TestLevel == "service":
				job.Passed++
			case r.NodeCheckMode == "connectivity" && item.ConnectivityReady && item.CleanupVerified && item.TestLevel == "connectivity" && item.Verdict == "PASS":
				job.Passed++
			case slices.Contains([]string{"BLOCKED", "MISROUTED", "FAIL"}, item.Verdict):
				job.Failed++
			default:
				job.Inconclusive++
			}
		}
		if a.nodeChecks.batchResults == nil {
			a.nodeChecks.batchResults = map[uint64]*nodeCheckJob{}
		}
		a.nodeChecks.batchResults[job.ID] = job
		if len(a.nodeChecks.batchResults) > 4 {
			var oldest *nodeCheckJob
			for id, candidate := range a.nodeChecks.batchResults {
				if id != job.ID && (oldest == nil || candidate.StartedAt.Before(oldest.StartedAt)) {
					oldest = candidate
				}
			}
			delete(a.nodeChecks.batchResults, oldest.ID)
		}
		for id, item := range pings {
			a.rememberNodePing(id, item)
		}
	}
	return out, nil
}

// durableNodeWindow bounds the nodes one durable step pings or screens.
const durableNodeWindow = 16

// eachNodeInParallel runs fn for 0..n-1 with at most limit at once.
func eachNodeInParallel(n, limit int, fn func(int)) {
	if n <= 0 {
		return
	}
	limit = min(max(limit, 1), n)
	next := make(chan int)
	var wg sync.WaitGroup
	for range limit {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for i := range next {
				fn(i)
			}
		}()
	}
	for i := range n {
		next <- i
	}
	close(next)
	wg.Wait()
}

// nodeCheckItemFromResult is the job row of a service check of a node.
func nodeCheckItemFromResult(id, profile string, result dataplane.NodeCheckResult, err error, engine string) nodeCheckItem {
	item := nodeCheckItem{NodeID: id, NetworkProfile: profile, CheckedAt: time.Now().UTC(), CleanupStatus: dataplane.NodeCleanupNotObserved}
	if engine == "sing-box" || engine == "xray" {
		item.Engine = engine // Selected executor, not proof that a process started.
	}
	if item.Engine != "" && result.NodeID == id && result.RoutePathID == engine+":"+id && (profile == "" || result.NetworkProfile == profile) {
		item.DirectEgressError = closedNodeEgressError(result.DirectEgressError)
		item.ProxyEgressError = closedNodeEgressError(result.ProxyEgressError)
		item.Stages = closedNodeCheckStages(result.Stages)
		switch result.Stage {
		case "dns", "transport", "configuration", "protocol", "route_identity", "egress", "service", "service_ip", "cleanup", "resource", "connectivity":
			item.Stage = result.Stage
		}
		if item.Stage == "service" || item.Stage == "service_ip" {
			switch result.ServiceErrorCategory {
			case "service_timeout", "service_transport", "service_status_mismatch":
				item.ServiceErrorCategory = result.ServiceErrorCategory
			}
		}
		switch result.DirectControl {
		case "not_run", "measured", "unavailable":
			item.DirectControl = result.DirectControl
		}
		if suffix, ok := strings.CutPrefix(result.ProbeID, "node-check-"); ok && len(suffix) == 24 && strings.Trim(suffix, "0123456789abcdef") == "" {
			item.ProbeID = result.ProbeID
		}
		switch result.CleanupStatus {
		case dataplane.NodeCleanupNotRequired, dataplane.NodeCleanupVerified, dataplane.NodeCleanupFailed:
			item.CleanupStatus = result.CleanupStatus
		}
		item.CleanupVerified = item.CleanupStatus == dataplane.NodeCleanupVerified
		if !result.StartedAt.IsZero() && !result.FinishedAt.Before(result.StartedAt) && result.ExpiresAt.After(result.FinishedAt) && result.ExpiresAt.Sub(result.FinishedAt) <= 24*time.Hour {
			item.CheckedAt, item.ExpiresAt = result.FinishedAt, result.ExpiresAt
		}
	}
	if err == nil {
		item.Available, item.DurationMS, item.Message = result.Available, result.LatencyMS, result.Message
		item.Verdict, item.TestLevel, item.ErrorCode = string(result.Verdict), result.TestLevel, result.ErrorCode
	} else {
		item.Message = nodeCheckFailureMessage(err)
		item.Verdict, item.TestLevel, item.ErrorCode = "INCONCLUSIVE", "unconfirmed", nodeCheckFailureCode(err)
	}
	// Preserve the existing fatal cleanup result even if history/admission also
	// failed. No positive check result or missing legacy field proves cleanup.
	if result.ErrorCode == "node-cleanup-failed" {
		item.Available, item.CleanupVerified = false, false
		item.CleanupStatus = dataplane.NodeCleanupFailed
		item.Verdict, item.TestLevel, item.ErrorCode = "INCONCLUSIVE", "unconfirmed", "node-cleanup-failed"
		item.Message = "Очистка временного процесса не подтверждена. Проверки остановлены до восстановления."
	}
	return item
}

// screenPing turns the transport stage of a screened node into the node's
// TCP ping, so a service check fills the ping column as well. UDP nodes have
// no TCP stage and no ping.
func screenPing(id, profile string, result dataplane.NodeCheckResult) nodeCheckItem {
	for _, stage := range result.Stages {
		if stage.ID != "transport" || stage.Status == "skipped" {
			continue
		}
		item := nodeCheckItem{NodeID: id, NetworkProfile: profile, CheckedAt: time.Now().UTC()}
		if stage.Status == "passed" {
			item.Reachable, item.LatencyMS, item.Message = true, max(stage.Duration, 1), "TCP-соединение установлено. Работу сервиса проверьте отдельно."
		} else {
			item.Message = "Сервер не принял TCP-соединение."
		}
		return item
	}
	return nodeCheckItem{}
}

// rememberNodePing keeps a bounded, process-local ping per node. Call with
// a.nodeChecks.mu held.
func (a *App) rememberNodePing(id string, item nodeCheckItem) {
	if a.nodeChecks.pings == nil {
		a.nodeChecks.pings = map[string]nodeCheckItem{}
	}
	if _, known := a.nodeChecks.pings[id]; !known && len(a.nodeChecks.pings) >= nodestore.MaxNodes {
		oldest := ""
		for key, value := range a.nodeChecks.pings {
			if oldest == "" || value.CheckedAt.Before(a.nodeChecks.pings[oldest].CheckedAt) {
				oldest = key
			}
		}
		delete(a.nodeChecks.pings, oldest)
	}
	a.nodeChecks.pings[id] = item
}

func (a *App) nodeBatchMemoryResults() map[uint64]nodeCheckJob {
	a.nodeChecks.mu.Lock()
	defer a.nodeChecks.mu.Unlock()
	results := make(map[uint64]nodeCheckJob, len(a.nodeChecks.batchResults))
	for id, job := range a.nodeChecks.batchResults {
		copy := *job
		copy.Results = slices.Clone(job.Results)
		results[id] = copy
	}
	return results
}

// The checker has joined cleanup before this runs. An old HTTP snapshot may
// still exist, so its epoch must also match the journal when merging results.
func (a *App) discardNodeBatchResults(id uint64, nodeIDs []string) {
	a.nodeChecks.mu.Lock()
	defer a.nodeChecks.mu.Unlock()
	delete(a.nodeChecks.batchResults, id)
	if a.nodeChecks.job != nil && a.nodeChecks.job.ID == id {
		a.nodeChecks.job = nil
	}
	for _, nodeID := range nodeIDs {
		delete(a.nodeChecks.pings, nodeID)
	}
}
